CREATE SCHEMA exam;
USE exam;

/*Creazione tabella Product*/
CREATE TABLE Product (
    ProductKey VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100),
    Category VARCHAR(100),
    ListPrice DECIMAL(10 , 2 )
);

/*Creazione tabella Region*/
CREATE TABLE Region (
    RegionKey VARCHAR(10) PRIMARY KEY,
    RegionName VARCHAR(100)
);

/*Creazione tabella Sales*/
CREATE TABLE Sales (
SalesOrderNumber VARCHAR(100) PRIMARY KEY,
OrderDate DATE,
ProductKey VARCHAR(10),
RegionKey VARCHAR(10),
OrderQuantity INT,
UnitPrice DECIMAL(10,2),
SalesAmount DECIMAL(10,2),
FOREIGN KEY (ProductKey)
        REFERENCES Product (ProductKey),
    FOREIGN KEY (RegionKey)
        REFERENCES Region (RegionKey));
        
/*Popolamento tabella Product*/
INSERT INTO Product VALUES
("E101", "Laboratory", "Education",	14.99),
("S101", "Racket", "Beach", 4.99),
("S102", "Water Gun", "Beach", 12.99),
("T101", "Cluedo", "Table",	29.99),
("T102", "Monopoly", "Table", 34.99),
("V101", "Scraper",	"Vehicle", 7.99),
("V102", "Truck","Vehicle", 49.99),
("V103", "Racer", "Vehicle", 16.99),
("Z101", "Hawaii", "Puzzle", 14.99),
("Z102", "Coliseum", "Puzzle", 29.99);

/*Popolamento tabella Region*/
INSERT INTO Region VALUES
("AZ", "Azerbaigian"),
("IT", "Italy"),
("UK", "United Kingdom"),
("US", "United States"),
("JAP", "Japan"),
("VEN", "Venezuela");

/*Popolamento tabella Sales*/
INSERT INTO Sales VALUES
("SON00001", "2022-02-13", "S102", "AZ", 12000, 4.99, 59880),
("SON00002", "2022-02-13", "T101", "IT", 10000, 29.99,	299900),
("SON00003", "2022-06-18", "T101", "UK",	22000,	20.00,	440000),
("SON00004", "2022-10-20", "Z101", "US",	26000,	14.99,	389740),
("SON00005", "2023-02-14", "V101", "US",	33000,	7.99,	263670),
("SON00006", "2023-02-14", "V102", "US",	23000,	49.99,	1149770),
("SON00007", "2023-06-19", "T101", "IT",	35000,	29.99,	1049650),
("SON00008", "2023-10-21", "V103", "JAP",	41000,	16.99,	696590),
("SON00009", "2023-12-22", "Z101", "UK",	13000,	14.00,	182000),
("SON00010", "2024-03-25", "V102", "IT",	15000,	49.99,	749850),
("SON00011", "2024-05-27", "S102", "IT",	28000,	12.99,	363720),
("SON00012", "2024-05-28", "V103", "JAP",	12000,	16.99,	203880),
("SON00013", "2024-05-29", "Z101", "UK",	11000,	14.00,	154000),
("SON00014", "2024-05-30", "V102", "IT",	24000,	49.99,	1199760);


/*1. Verificare che i campi definiti come PK siano univoci.  */

/*Per verificarlo mi aspetto che la frequenza delle PK (ProductKey per Product, 
RegionKey per Region e SalesOrderNumber per Sales) aggregate sia uguale a 1,
 quindi mettendo una frequenza maggiore di 1 non dovrei avere nessun output*/
 
SELECT 
    ProductKey, COUNT(*) AS frequenza
FROM
    product
GROUP BY ProductKey
HAVING frequenza > 1;

SELECT 
    RegionKey, COUNT(*) AS frequenza
FROM
    Region
GROUP BY RegionKey
HAVING frequenza > 1;

SELECT 
    SalesOrderNumber, COUNT(*) AS frequenza
FROM
    Sales
GROUP BY SalesOrderNumber
HAVING frequenza > 1;


/*2. Esporre l’elenco dei soli prodotti venduti e 
per ognuno di questi il fatturato totale per anno.*/

SELECT 
    p.Name AS Prodotto,
    YEAR(s.OrderDate) AS Anno,
    SUM(s.SalesAmount) AS Fatturato
FROM
    product AS p
        INNER JOIN
    sales AS s ON p.ProductKey = s.ProductKey
GROUP BY p.Name , YEAR(s.OrderDate);


/*3. Esporre il fatturato totale per stato per anno. 
Ordina il risultato per data e per fatturato decrescente. */

SELECT 
    r.RegionName AS Stato,
    YEAR(s.OrderDate) AS Anno,
    SUM(s.SalesAmount) AS Fatturato
FROM
    region AS r
        LEFT JOIN
    sales AS s ON r.RegionKey = s.RegionKey
GROUP BY Stato, Anno
ORDER BY Anno DESC , Fatturato DESC;
/*N.B. Ho volutamente fatto una left join da region a sales per 
evidenziare che non ci sono state vendite in Venezuela */


/*4. Rispondere alla seguente domanda: 
qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT 
    p.Category AS Categoria,
    SUM(s.OrderQuantity) AS Quantità_Richiesta
FROM
    product AS p
        LEFT JOIN
    sales AS s ON p.ProductKey = s.ProductKey
GROUP BY Categoria
ORDER BY Quantità_Richiesta DESC
LIMIT 1;

/*La categoria di articoli maggiormente richiesta è quindi Vehicle*/


/*5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
Proponi due approcci risolutivi differenti.*/
/*Approccio con left join, nella selezione ho volutamente mostrato anche la colonna Quantità
 per evidenziare il fatto che sono presenti valori nulli*/
SELECT 
    p.Name AS Prodotto, s.OrderQuantity AS Quantità
FROM
    product AS p
        LEFT JOIN
    sales AS s ON p.ProductKey = s.ProductKey
WHERE
    s.OrderQuantity IS NULL;
   
/*Approccio con subquery*/
    SELECT 
    p.Name AS Prodotto
FROM
    product AS p
WHERE
    p.ProductKey NOT IN (SELECT 
            s.ProductKey
        FROM
            sales AS s);
            
            
/*6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita 
(la data di vendita più recente).*/
SELECT 
    p.Name AS Prodotto,
    max(s.OrderDate) AS Data_Ultima_Vendita
FROM
    product AS p
        INNER JOIN
    sales AS s ON p.ProductKey = s.ProductKey
    group by Prodotto;
